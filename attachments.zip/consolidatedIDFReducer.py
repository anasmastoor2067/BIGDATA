#!/usr/bin/env python

import sys
import math

def reducer():
    doc_frequency = {}
    num_documents = 0

    for line in sys.stdin:
        term, _ = line.strip().split('\t', 1)
        doc_frequency[term] = doc_frequency.get(term, 0) + 1
        num_documents += 1

    idf_scores = {}
    for term, freq in doc_frequency.items():
        idf_scores[term] = math.log(num_documents / (freq + 1))  # Adding 1 to avoid division by zero

    for term, idf_score in idf_scores.items():
        print('%s\t%s' % (term, idf_score))

if __name__ == "__main__":
    reducer()
