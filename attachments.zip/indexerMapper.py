#!/usr/bin/env python

import sys
import os
from collections import defaultdict

def mapper():
    idf_scores = load_idf_scores("idf_file.txt")  # Load IDF scores from file
    for root, dirs, files in os.walk("corpus"):
        for file_name in files:
            document_id = os.path.splitext(file_name)[0]
            document_vector = defaultdict(float)  # Initialize TF-IDF vector for the document
            with open(os.path.join(root, file_name), 'r', encoding='utf-8') as file:
                words = file.read().strip().split()
                term_frequency = defaultdict(int)
                max_tf = 0
                for word in words:
                    term_frequency[word] += 1
                    if term_frequency[word] > max_tf:
                        max_tf = term_frequency[word]
                for word, tf in term_frequency.items():
                    tf_idf = (tf / max_tf) * idf_scores.get(word, 0)
                    print('%s\t%s\t%s' % (document_id, word, tf_idf))

def load_idf_scores(idf_file):
    idf_scores = {}
    with open(idf_file, 'r', encoding='utf-8') as file:
        for line in file:
            term, idf = line.strip().split(': ')
            idf_scores[term] = float(idf)
    return idf_scores

if __name__ == "__main__":
    mapper()
