#!/usr/bin/env python

import sys

def mapper():
    for line in sys.stdin:
        words = line.strip().split()
        for word in words:
            print('%s\t%s' % (word, 1))

if __name__ == "__main__":
    mapper()
