{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "f09e2db8-b8c2-4683-8083-e641d0d50204",
   "metadata": {},
   "outputs": [],
   "source": [
    "#!/usr/bin/env python\n",
    "\n",
    "import sys\n",
    "import nltk\n",
    "import string\n",
    "from nltk.corpus import stopwords\n",
    "\n",
    "# Load English stopwords\n",
    "stop_words = set(stopwords.words('english'))\n",
    "\n",
    "# Mapper function\n",
    "def mapper():\n",
    "    for line in sys.stdin:\n",
    "        # Tokenize the content\n",
    "        tokens = nltk.word_tokenize(line)\n",
    "        # Remove stopwords, punctuation, and symbols\n",
    "        filtered_tokens = [word.lower() for word in tokens if word.lower() not in stop_words and word.lower() not in string.punctuation and word.isalnum()]\n",
    "        # Emit key-value pairs\n",
    "        for word in filtered_tokens:\n",
    "            print('%s\\t%s' % (word, 1))\n",
    "\n",
    "if __name__ == \"__main__\":\n",
    "    mapper()\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "e20379dc-4dfe-4783-9f6a-5e0fa30cca4a",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
