#!/usr/bin/env python

import sys

def reducer():
    current_id = 0
    word_to_id = {}
    for line in sys.stdin:
        word, _ = line.strip().split('\t', 1)
        if word not in word_to_id:
            word_to_id[word] = current_id
            current_id += 1

    for word, word_id in word_to_id.items():
        print('%s\t%s' % (word, word_id))

if __name__ == "__main__":
    reducer()
