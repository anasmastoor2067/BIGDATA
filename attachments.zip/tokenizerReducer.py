#!/usr/bin/env python

import sys

# Reducer function
def reducer():
    current_word = None
    current_count = 0
    for line in sys.stdin:
        # Parse the input we got from mapper.py
        word, count = line.strip().split('\t', 1)
        # Convert count (currently a string) to int
        try:
            count = int(count)
        except ValueError:
            # Count was not a number, so silently ignore this line
            continue
        # Process the same word
        if current_word == word:
            current_count += count
        else:
            # A new word encountered
            if current_word:
                # Emit word count
                print('%s\t%s' % (current_word, current_count))
            current_count = count
            current_word = word

    # Output the last word
    if current_word == word:
        print('%s\t%s' % (current_word, current_count))

if __name__ == "__main__":
    reducer()
