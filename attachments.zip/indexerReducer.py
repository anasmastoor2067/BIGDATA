#!/usr/bin/env python

import sys
from collections import defaultdict

def reducer():
    current_document = None
    current_document_vector = defaultdict(float)
    for line in sys.stdin:
        document_id, word, tf_idf = line.strip().split('\t')
        tf_idf = float(tf_idf)
        if current_document == document_id:
            current_document_vector[word] = tf_idf
        else:
            if current_document:
                print('%s\t%s' % (current_document, current_document_vector))
            current_document = document_id
            current_document_vector = defaultdict(float)
            current_document_vector[word] = tf_idf

    # Output the last document vector
    if current_document:
        print('%s\t%s' % (current_document, current_document_vector))

if __name__ == "__main__":
    reducer()
